#pragma once
// Stub license header
#define CH_LICENSE "Stub ChibiOS License"
