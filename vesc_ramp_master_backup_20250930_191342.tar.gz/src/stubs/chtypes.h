// stub chtypes.h
