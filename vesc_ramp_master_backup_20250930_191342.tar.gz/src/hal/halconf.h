#ifndef HALCONF_H
#define HALCONF_H

#define HAL_USE_UART                    TRUE
#define HAL_USE_SERIAL                  TRUE
#define HAL_USE_I2C                     FALSE
#define HAL_USE_SPI                     FALSE
#define HAL_USE_ADC                     FALSE
#define HAL_USE_PWM                     FALSE

#endif
