typedef unsigned char msg_t;
typedef unsigned int systime_t;
