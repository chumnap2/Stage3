#!/bin/bash
# add_thread_stub.sh
# Adds minimal ChibiOS thread stubs for Stage3 demo

# Ensure BASE_DIR points to the project root
BASE_DIR="$(pwd)"

# Create include directory if missing
mkdir -p "$BASE_DIR/include"
# Create src directory if missing
mkdir -p "$BASE_DIR/src"

# -------------------------
# thread.hpp stub
cat > "$BASE_DIR/include/thread.hpp" << 'EOT'
/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS thread stub for Stage3 demo
 * File   : thread.hpp
 */
#ifndef THREAD_HPP
#define THREAD_HPP

class Thread {
public:
    Thread() {}
    template<typename Func>
    void start(Func&& func) {
        // Minimal stub: call the function immediately
        func();
    }
};

#endif
EOT

# -------------------------
# thread.cpp stub
cat > "$BASE_DIR/src/thread.cpp" << 'EOT'
/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS thread stub implementation
 * File   : thread.cpp
 */
#include "thread.hpp"
// Nothing to implement, stub only
EOT

# -------------------------
# test.cpp stub
cat > "$BASE_DIR/src/test.cpp" << 'EOT'
/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal test for thread stub
 * File   : test.cpp
 */
#include "thread.hpp"
#include <iostream>

void hello() {
    std::cout << "Thread stub running!" << std::endl;
}

int main() {
    Thread t;
    t.start(hello);
    return 0;
}
EOT

echo "[SUCCESS] Minimal thread stubs added and test.cpp created"
