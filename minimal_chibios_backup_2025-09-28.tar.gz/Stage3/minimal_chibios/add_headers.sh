#!/bin/bash
# add_headers.sh
# Prepends author/date/purpose headers to all C++ stub files

AUTHOR="Chumnap Thach"
DATE="$(date +%Y-%m-%d)"
PURPOSE="Minimal ChibiOS stub file for Stage3 demo"

# Directories to scan
DIRS=("src" "include")

for DIR in "${DIRS[@]}"; do
    for FILE in "$DIR"/*.{cpp,hpp}; do
        [ -f "$FILE" ] || continue  # skip if no matching file
        TMP_FILE="${FILE}.tmp"
        
        # Skip file if header already exists
        if ! grep -q "Author : $AUTHOR" "$FILE"; then
            # Prepend header
            cat > "$TMP_FILE" <<EOF
/*
 * Author : $AUTHOR
 * Date   : $DATE
 * Purpose: $PURPOSE
 * File   : $(basename "$FILE")
 */
EOF
            # Append original file content
            cat "$FILE" >> "$TMP_FILE"
            # Replace original file
            mv "$TMP_FILE" "$FILE"
            echo "[HEADER ADDED] $FILE"
        fi
    done
done

echo "[SUCCESS] Headers added to all stub files"
