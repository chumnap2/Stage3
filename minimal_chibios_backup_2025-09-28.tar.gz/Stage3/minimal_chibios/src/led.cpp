/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS stub file for Stage3 demo
 * File   : led.cpp
 */
#include "led.hpp"
// minimal stub, nothing to implement
