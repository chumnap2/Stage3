/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal test stub for Stage3 demo
 * File   : test_stub.cpp
 */
#include <iostream>
#include "../include/thread.hpp"

void hello() {
    std::cout << "[TEST] Hello from minimal thread!" << std::endl;
}

int main() {
    Thread t(hello);
    t.start();
    // Give the thread some time to run
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    return 0;
}
