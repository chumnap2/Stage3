/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS thread implementation stub
 * File   : thread.cpp
 */
#include "thread.hpp"
// Minimal thread implementation handled in header
