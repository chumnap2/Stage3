/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal test demonstrating threads
 * File   : test.cpp
 */
#include "thread.hpp"
#include <iostream>

void hello1() { std::cout << "Hello from thread 1\n"; }
void hello2() { std::cout << "Hello from thread 2\n"; }

int main() {
    Thread t1, t2;
    t1.start(hello1);
    t2.start(hello2);

    t1.join();
    t2.join();

    std::cout << "All threads finished\n";
    return 0;
}
