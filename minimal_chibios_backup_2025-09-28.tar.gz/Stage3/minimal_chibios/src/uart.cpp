/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS stub file for Stage3 demo
 * File   : uart.cpp
 */
#include "uart.hpp"
// minimal stub, nothing to implement
