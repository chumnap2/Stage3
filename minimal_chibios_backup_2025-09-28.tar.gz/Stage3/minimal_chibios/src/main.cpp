/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS stub file for Stage3 demo
 * File   : main.cpp
 */
#include "led.hpp"
#include "uart.hpp"

int main() {
    LED::init();
    UART::init();
    return 0;
}
