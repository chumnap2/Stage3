#!/bin/bash
# create_minimal_stubs.sh
# This script sets up a minimal ChibiOS stub project

# Base directory
BASE_DIR="$PWD"

# Create necessary directories
mkdir -p "$BASE_DIR/src" "$BASE_DIR/include" "$BASE_DIR/cmake"

# -------------------------
# main.cpp stub
cat > "$BASE_DIR/src/main.cpp" <<'EOF'
#include "led.hpp"
#include "uart.hpp"

int main() {
    LED::init();
    UART::init();
    return 0;
}
EOF

# -------------------------
# led.hpp stub
cat > "$BASE_DIR/include/led.hpp" <<'EOF'
#ifndef LED_HPP
#define LED_HPP
class LED {
public:
    static void init() {}
    static void on() {}
    static void off() {}
};
#endif
EOF

# -------------------------
# uart.hpp stub
cat > "$BASE_DIR/include/uart.hpp" <<'EOF'
#ifndef UART_HPP
#define UART_HPP
class UART {
public:
    static void init() {}
    static void write(const char*) {}
};
#endif
EOF

# -------------------------
# uart.cpp stub
cat > "$BASE_DIR/src/uart.cpp" <<'EOF'
#include "uart.hpp"
// minimal stub, nothing to implement
EOF

# -------------------------
# led.cpp stub
cat > "$BASE_DIR/src/led.cpp" <<'EOF'
#include "led.hpp"
// minimal stub, nothing to implement
EOF

echo "[SUCCESS] Minimal ChibiOS stub project created in $BASE_DIR"
