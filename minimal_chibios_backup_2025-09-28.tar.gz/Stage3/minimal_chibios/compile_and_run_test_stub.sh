#!/bin/bash
# Compile and run minimal thread test stub for Stage3

BASE_DIR="$(pwd)"
SRC_DIR="$BASE_DIR/src"
INCLUDE_DIR="$BASE_DIR/include"
BUILD_DIR="$BASE_DIR/build_test_stub"

# Create build directory if it doesn't exist
mkdir -p "$BUILD_DIR"

# Compile the test stub
g++ -std=c++17 "$SRC_DIR/test_stub.cpp" "$SRC_DIR/thread.cpp" -I"$INCLUDE_DIR" -o "$BUILD_DIR/test_stub" -pthread

# Check if compilation succeeded
if [ $? -eq 0 ]; then
    echo "[SUCCESS] Compilation succeeded, running test stub..."
    "$BUILD_DIR/test_stub"
else
    echo "[ERROR] Compilation failed!"
fi
