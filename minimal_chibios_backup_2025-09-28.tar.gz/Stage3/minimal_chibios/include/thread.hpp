/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS thread stub for Stage3 demo
 * File   : thread.hpp
 */
#ifndef THREAD_HPP
#define THREAD_HPP

#include <thread>
#include <functional>

class Thread {
public:
    Thread(std::function<void()> func) : t(func) {}
    void start() { t.detach(); }  // minimal stub
private:
    std::thread t;
};

#endif // THREAD_HPP
