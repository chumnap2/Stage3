/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS stub file for Stage3 demo
 * File   : led.hpp
 */
#ifndef LED_HPP
#define LED_HPP
class LED {
public:
    static void init() {}
    static void on(int pin = 0) {}
    static void off(int pin = 0) {}
    static void toggle(int pin = 0) {}
};
#endif
