/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS stub file for Stage3 demo
 * File   : uart.hpp
 */
#ifndef UART_HPP
#define UART_HPP
class UART {
public:
    static void init() {}
    static void write(const char* msg) {}
    static void write_fmt(const char* fmt, ...) {}
};
#endif
