#!/bin/bash
# add_thread_and_test_stubs.sh
# Adds minimal thread and test stubs for Stage3 demo

BASE_DIR="$PWD"

# Create include and src directories
mkdir -p "$BASE_DIR/include" "$BASE_DIR/src"

# -------------------------
# include/thread.hpp
cat > "$BASE_DIR/include/thread.hpp" <<'EOF'
/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal ChibiOS thread stub for Stage3 demo
 * File   : thread.hpp
 */
#ifndef THREAD_HPP
#define THREAD_HPP

#include <thread>
#include <functional>

class Thread {
public:
    Thread(std::function<void()> func) : t(func) {}
    void start() { t.detach(); }  // minimal stub
private:
    std::thread t;
};

#endif // THREAD_HPP
EOF

# -------------------------
# src/test_stub.cpp
cat > "$BASE_DIR/src/test_stub.cpp" <<'EOF'
/*
 * Author : Chumnap Thach
 * Date   : 2025-09-28
 * Purpose: Minimal test stub for Stage3 demo
 * File   : test_stub.cpp
 */
#include <iostream>
#include "../include/thread.hpp"

void hello() {
    std::cout << "[TEST] Hello from minimal thread!" << std::endl;
}

int main() {
    Thread t(hello);
    t.start();
    // Give the thread some time to run
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    return 0;
}
EOF

echo "[SUCCESS] Minimal thread and test stubs created in $BASE_DIR"
