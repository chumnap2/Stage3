#!/bin/bash
# regen_chibios.sh
# Auto-generate minimal chconf.h and toolchain.cmake for F' demo

set -e

BASE_DIR=$(dirname "$(realpath "$0")")
CHCONF_FILE="$BASE_DIR/chconf.h"
TOOLCHAIN_FILE="$BASE_DIR/toolchain.cmake"

echo "[INFO] Generating minimal chconf.h..."

cat > "$CHCONF_FILE" << 'EOF'
#ifndef CHCONF_H
#define CHCONF_H

/*
 * Minimal ChibiOS configuration for F´ demo
 */

#define CH_CFG_IRQ_PROLOGUE_HOOK        NULL
#define CH_CFG_IRQ_EPILOGUE_HOOK        NULL

#define CH_CFG_USE_REGISTRY             FALSE
#define CH_CFG_USE_WAITEXIT              FALSE
#define CH_CFG_USE_SEMAPHORES            FALSE
#define CH_CFG_USE_SEMAPHORES_PRIORITY   FALSE
#define CH_CFG_USE_MUTEXES               FALSE
#define CH_CFG_USE_MUTEXES_RECURSIVE     FALSE
#define CH_CFG_USE_CONDVARS              FALSE
#define CH_CFG_USE_CONDVARS_TIMEOUT      FALSE
#define CH_CFG_USE_MESSAGES              FALSE
#define CH_CFG_USE_MESSAGES_PRIORITY     FALSE
#define CH_CFG_USE_MAILBOXES             FALSE
#define CH_CFG_USE_MEMCORE               FALSE
#define CH_CFG_USE_HEAP                  FALSE
#define CH_CFG_USE_DYNAMIC               FALSE
#define CH_CFG_USE_USER_MAIN             FALSE
#define CH_CFG_USE_TRACE                 FALSE
#define CH_CFG_USE_STATS                 FALSE
#define CH_CFG_USE_TM                    FALSE
#define CH_CFG_USE_TIMESTAMP             FALSE

/* Hooks */
#define CH_CFG_THREAD_INIT_HOOK          NULL
#define CH_CFG_THREAD_EXIT_HOOK          NULL
#define CH_CFG_IDLE_LOOP_HOOK            NULL
#define CH_CFG_SYSTEM_TICK_HOOK          NULL
#define CH_CFG_CONTEXT_SWITCH_HOOK       NULL
#define CH_CFG_OS_INSTANCE_INIT_HOOK     NULL
#define CH_CFG_OS_INSTANCE_EXTRA_FIELDS

/* Scheduler & time */
#define CH_CFG_ST_RESOLUTION             1
#define CH_CFG_ST_FREQUENCY              1000
#define CH_CFG_ST_TIMEDELTA              1
#define CH_CFG_TIME_QUANTUM              1
#define CH_CFG_MEMCORE_SIZE              1024
#define CH_CFG_NO_IDLE_THREAD            FALSE
#define CH_CFG_OPTIMIZE_SPEED            TRUE
#define CH_CFG_SMP_MODE                  FALSE
#define CH_CFG_HARDENING_LEVEL           0
#define CH_CFG_INTERVALS_SIZE            16
#define CH_CFG_TIME_TYPES_SIZE           8

#endif /* CHCONF_H */
EOF

echo "[SUCCESS] chconf.h created ✅"

echo "[INFO] Generating minimal toolchain.cmake..."

cat > "$TOOLCHAIN_FILE" << 'EOF'
# Minimal toolchain.cmake for ARM cross-compilation
set(CMAKE_SYSTEM_NAME Generic)
set(CMAKE_SYSTEM_PROCESSOR arm)

# Specify cross compiler
set(CMAKE_C_COMPILER   arm-none-eabi-gcc)
set(CMAKE_CXX_COMPILER arm-none-eabi-g++)

# Minimal compiler flags
set(CMAKE_C_FLAGS   "-mcpu=cortex-m3 -mthumb -Os")
set(CMAKE_CXX_FLAGS "-mcpu=cortex-m3 -mthumb -Os -fno-exceptions -fno-rtti")

# Linker flags (adjust as needed)
set(CMAKE_EXE_LINKER_FLAGS "-T${CMAKE_SOURCE_DIR}/linker_script.ld")
EOF

echo "[SUCCESS] toolchain.cmake created ✅"
