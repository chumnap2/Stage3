#pragma once
typedef int sysinterval_t;
typedef int time_conv_t;

#define TIME_MS2I(msecs) ((sysinterval_t)(msecs))
