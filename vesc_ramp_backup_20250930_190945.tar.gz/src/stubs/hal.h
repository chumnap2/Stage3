#pragma once
// Stub HAL header
static inline void halInit(void) {
    // no-op
}
