#pragma once
#include "chthreads.h"
#include "chtime.h"
#include "chlicense.h"

static inline void chSysInit(void) {
    // Stub system init
}
