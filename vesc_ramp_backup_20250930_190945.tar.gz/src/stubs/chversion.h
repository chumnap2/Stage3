// stub chversion.h
