// Stub chlib.h
